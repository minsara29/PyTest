def test_a1():
    assert 4 < 5 

def test_a2():
    # assert 4 > 5, "making fail" 
    assert 5 == 5 

def test_a3():
    assert 1 in divmod(9,5) # return in tuple (1, 4) quotient  and remainder 