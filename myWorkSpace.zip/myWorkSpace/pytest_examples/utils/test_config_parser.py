from pytest_examples.utils.config_parser import *


def test_get_gmailurl():
    print(get_gmailUrl())